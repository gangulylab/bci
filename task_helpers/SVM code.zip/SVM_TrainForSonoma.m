
% load condn data here

% imagined movement

clear;clc
close all

root='E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\';

folders = {'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200911\CenterOut\145330\Imagined\',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200911\CenterOut\145855\Imagined\',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200911\CenterOut\150113\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200911\CenterOut\150229\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200911\CenterOut\150556\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200911\CenterOut\153125\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200911\CenterOut\155038\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200918\CenterOut\145458\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200918\CenterOut\151515\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200918\CenterOut\154012\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200918\CenterOut\155929\Imagined',...
    'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20200925\CenterOut\145022\Imagined'};



% collecting all the training data
files=[];
for i=1:length(folders)
    cd(folders{i})
    temp = findfiles('',pwd);
    files=[files;temp'];
end




% load the data for each target
D1=[];
D2=[];
D3=[];
D4=[];
D5=[];
D6=[];
D7=[];
D8=[];
for i=1:length(files)
    disp(i)
    load(files{i});
    features  = TrialData.NeuralFeatures;
    kinax = length(features)+[-20:0];
    temp = cell2mat(features(kinax));
    temp = temp(129:end,:);
    for j=1:size(temp,1)
        temp(j,:) = smooth(temp(j,:),3);
    end
    if TrialData.TargetID == 1
        D1 = [D1 temp];
    elseif TrialData.TargetID == 2
        D2 = [D2 temp];
    elseif TrialData.TargetID == 3
        D3 = [D3 temp];
    elseif TrialData.TargetID == 4
        D4 = [D4 temp];
    elseif TrialData.TargetID == 5
        D5 = [D5 temp];
    elseif TrialData.TargetID == 6
        D6 = [D6 temp];
    elseif TrialData.TargetID == 7
        D7 = [D7 temp];
    elseif TrialData.TargetID == 8
        D8 = [D8 temp];
    end
end

% TACKING ON THE ONLINE DISCRETE DATA SESSION 6 ARROW TASK
filepath = 'E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker\20201113\DiscreteArrow\';
% discrete arrow
folders = {'135938','140554'};% 
folders1 = '';
% together
folders =[ folders folders1];
files=[];
for i=1:length(folders)
    fullpath = [filepath folders{i} '\BCI_Fixed\'];
    files = [files findfiles('', fullpath)];
end

% load the data for each target
D6_1=[];
D6_2=[];
D6_3=[];
D6_4=[];
for i=1:length(files)
    disp(i)
    load(files{i});
    features  = TrialData.SmoothedNeuralFeatures;
    kinax = TrialData.TaskState;
    if kinax(1) == 0
        kinax=kinax(2:end);
    end
    kinax = find(kinax==3);
    l=length(kinax)+1;
    kinax = kinax(l-TrialData.Params.ClickCounter:end);
    if TrialData.TargetID == TrialData.SelectedTargetID
        temp = cell2mat(features(kinax));
        temp = temp(129:end,:);        
        if TrialData.TargetID == 1
            D6_1 = [D6_1 temp];
        elseif TrialData.TargetID == 2
            D6_2 = [D6_2 temp];
        elseif TrialData.TargetID == 3
            D6_3 = [D6_3 temp];
        elseif TrialData.TargetID == 4
            D6_4 = [D6_4 temp];
        end
    end
end


clear condn_data
% combing both onlien plus offline
idx=641;
condn_data{1}=[D1(idx:end,:) D11(idx:end,:) D2_1(idx:end,:) D3_1(idx:end,:) D5_1(idx:end,:) D6_1(idx:end,:) D7_1(idx:end,:) D8_1(idx:end,:) D9_1(idx:end,:) ]'; % right hand
condn_data{2}= [D3(idx:end,:) D22(idx:end,:) D2_2(idx:end,:) D3_2(idx:end,:) D5_2(idx:end,:) D6_2(idx:end,:) D7_2(idx:end,:) D8_2(idx:end,:) D9_2(idx:end,:)]'; % both feet and right foot here
condn_data{3}=[D5(idx:end,:) D33(idx:end,:) D2_3(idx:end,:) D3_3(idx:end,:) D5_3(idx:end,:) D6_3(idx:end,:) D7_3(idx:end,:) D8_3(idx:end,:) D9_3(idx:end,:)]'; % left hand
condn_data{4}=[D7(idx:end,:) D44(idx:end,:) D2_4(idx:end,:) D3_4(idx:end,:) D5_4(idx:end,:) D6_4(idx:end,:) D7_4(idx:end,:) D8_4(idx:end,:) D9_4(idx:end,:)]'; % head
cd('E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker')




% MUTLIC-CLASS CLASSIFIERS AND ASSIGNING MAX SCORES
% partition the data
Conf_Matrix_Overall=[];
for iter=1:5
    condn_data_train={};
    condn_data_test={};
    for i=1:length(condn_data)
        temp = condn_data{i};
        l = round(0.75*size(temp,1));
        idx = randperm(size(temp,1),l);
        %idx = 1:l;
        % setting aside training trials
        condn_data_train{i} = temp(idx,:);
        % setting aside testing trials
        I = ones(size(temp,1),1);
        I(idx)=0;
        I=logical(I);
        condn_data_test{i} = temp(I,:);
    end
    
    % build the classifiers
    svm_model={};D=[];idx = [1:128 385:514 641:768];
    for i=1:length(condn_data_train)
        disp(i)
        A = [condn_data_train{i}];
        A=[A(:,idx) ];
        for j=i:length(condn_data_train)
            if i==j
                svm_model{i,j}=0;
            else
                B = [condn_data_train{j}];
                B=[B(:,idx) ];
                [res_acc, model,pval] = svm_linear(A',B',1,1);
                %[model] = svm_nonlinear(A',B',1);                
                %no pruning 
                svm_model{i,j} = mean(model,1);
                svm_model{j,i} = -mean(model,1);                
                % pruning weights
%                 temp_wts = mean(model,1);
%                 [aa bb]=sort(abs(temp_wts));
%                 len = round(0.5*length(temp_wts));
%                 temp_wts(bb(1:len))=0;
%                 svm_model{i,j} = temp_wts;
%                 svm_model{j,i} = -temp_wts;
            end
        end
    end
    
    
%     % non-linear
%     clear model
%     model = svm_model;
%     cd('E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker')
%     save clicker_svm_mdl_Days123_5Partial_OnlyArrow_RBF model -v7.3
    
    % collate the condition specific classifiers
    models=[];
    for i=1:size(svm_model,1)
        temp=[];
        for j=1:size(svm_model,2)
            if length(svm_model{i,j}) > 1
                temp=[temp;svm_model{i,j}];
            end
        end
        models(i,:,:)=temp;
    end
    model = models;
    %cd('E:\DATA\ecog data\ECoG BCI\GangulyServer\Multistate clicker')
    %save clicker_svm_mdl_6Dir_hG model -v7.3
    
    % now test them based on max vote strategy
    % i.e. test each data point on whether it came from one of the 8 classes
    Conf_Matrix=[];
    num_trials=[];
    for i=1:length(condn_data_test)
        temp = condn_data_test{i};
        temp = temp(:,idx);
        % smooth data moving average
        %         for k=1:size(temp,2)
        %             temp(:,k) = smooth(temp(:,k),5);
        %         end
        predicted_classes=zeros(1,length(condn_data_test));
        for j=1:size(temp,1)
            d1 = temp(j,:)*squeeze(models(1,:,:))';
            d2 = temp(j,:)*squeeze(models(2,:,:))';
            d3 = temp(j,:)*squeeze(models(3,:,:))';
            d4 = temp(j,:)*squeeze(models(4,:,:))';
            d5 = temp(j,:)*squeeze(models(5,:,:))';
            d6 = temp(j,:)*squeeze(models(6,:,:))';
%             d7 = temp(j,:)*squeeze(models(7,:,:))';
%             d8 = temp(j,:)*squeeze(models(8,:,:))';
%             d9 = temp(j,:)*squeeze(models(9,:,:))';
%             d10 = temp(j,:)*squeeze(models(10,:,:))';
%             d11 = temp(j,:)*squeeze(models(11,:,:))';
%             d12 = temp(j,:)*squeeze(models(12,:,:))';
            Dec = [d1;d2;d3;d4;d5;d6];
            Dec_values=[sum(d1);sum(d2);sum(d3);sum(d4);sum(d5);sum(d6)];
            %Dec = [d1;d2;d3;d4;];
            %Dec_values=[sum(d1);sum(d2);sum(d3);sum(d4)];            
            Dec_thresh=sum(Dec'<0);
            
            %%on max vote strategy
            [aa bb]=max(Dec_thresh);
            if length(find(Dec_thresh==aa)) == 1
                predicted_classes(bb)=predicted_classes(bb)+1;
            else
                [aa1 bb1]=min(Dec_values);
                predicted_classes(bb1)=predicted_classes(bb1)+1;
            end
            
            %%on max distance from decision boundary
%             Dec_values(Dec_values>-3)=0;
%             [aa1 bb1]=min(Dec_values);
%             if aa1~=0
%                 decision = bb1;
%                 predicted_classes(bb1)=predicted_classes(bb1)+1;
%             end
        end
        Conf_Matrix(i,:) = predicted_classes./sum(predicted_classes);
        num_trials = [num_trials sum(predicted_classes)/j];
    end
    figure;imagesc(Conf_Matrix);colormap bone;caxis([0 .8]);
    Conf_Matrix;
    diag(Conf_Matrix);
    Conf_Matrix_Overall(iter,:,:)=Conf_Matrix;
end
Conf_Matrix = squeeze(mean(Conf_Matrix_Overall,1));
diag(Conf_Matrix)
figure;stem(ans,'LineWidth',1)
figure;imagesc(Conf_Matrix);colormap bone;caxis([0 .8]);

xticklabels({'Right hand','Both Feet','Left hand','Head',...
    'Imag. up','Imag. down','Tongue out','Tongue in'})
yticklabels({'Right hand','Both Feet','Left hand','Head',...
    'Imag. up','Imag. down','Tongue out','Tongue in'})
set(gcf,'Color','w')
set(gca,'FontSize',14)
hh=hline(1/4);
set(hh,'LineWidth',2)
set(gcf,'Color','w')
set(gca,'FontSize',14)
figure;imagesc(Conf_Matrix);colormap bone;caxis([0.05 .8]);
xticks([1 2 3 4])
yticks([1 2 3 4])
xticklabels({'Right arm','Left arm','Right leg','Left leg'})
yticklabels({'Right arm','Left arm','Right leg','Left leg'})
set(gcf,'Color','w')
set(gca,'FontSize',14)
title('Confusion Matrix')
colorbar
